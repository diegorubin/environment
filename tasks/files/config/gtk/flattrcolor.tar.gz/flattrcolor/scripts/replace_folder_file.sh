#!/usr/bin/env bash
#	default color: 178984
oldglyph=#6e6344
newglyph=#34352c

#	Front
#	default color: 36d7b7
oldfront=#bba974
newfront=#656754

#	Back
#	default color: 1ba39c
oldback=#817450
newback=#45463a

sed -i "s/#524954/$oldglyph/g" $1
sed -i "s/#9b8aa0/$oldfront/g" $1
sed -i "s/#716475/$oldback/g" $1
sed -i "s/$oldglyph;/$newglyph;/g" $1
sed -i "s/$oldfront;/$newfront;/g" $1
sed -i "s/$oldback;/$newback;/g" $1
