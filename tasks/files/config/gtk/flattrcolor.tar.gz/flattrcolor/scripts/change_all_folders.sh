#!/usr/bin/env bash
#
# 64px folders
#
./replace_folder_file.sh ../places/64/folder-documents.svg
./replace_folder_file.sh ../places/64/folder-download.svg
./replace_folder_file.sh ../places/64/folder-music.svg
./replace_folder_file.sh ../places/64/folder-network.svg
./replace_folder_file.sh ../places/64/folder-pictures.svg
./replace_folder_file.sh ../places/64/folder-publicshare.svg
./replace_folder_file.sh ../places/64/folder.svg
./replace_folder_file.sh ../places/64/folder-templates.svg
./replace_folder_file.sh ../places/64/folder-videos.svg
./replace_folder_file.sh ../places/64/user-home.svg

